VEET Dashboard (Discord OAuth2 + MongoDB)

Setup:
1. npm install
2. create .env from .env.example and set secrets
3. npm run dev
4. set Discord redirect to DISCORD_REDIRECT_URI in Developer Portal
