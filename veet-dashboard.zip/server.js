const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const path = require("path");
const mongoose = require("mongoose");
const axios = require("axios");
const dotenv = require("dotenv");
dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const SECRET_KEY = process.env.SECRET_KEY || "veet_secret_dev";
const BOT_API_KEY = process.env.BOT_API_KEY || "veet_bot_api_key_dev";
const MONGO_URI = process.env.MONGO_URI || null;
const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID || "";
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || "";
const DISCORD_REDIRECT_URI = process.env.DISCORD_REDIRECT_URI || "http://localhost:3000/auth/discord/callback";
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,"public")));
let EconomyModel=null, UserModel=null, ServerModel=null;
async function initMongo(){ if (!MONGO_URI) return; try{ await mongoose.connect(MONGO_URI); const econSchema=new mongoose.Schema({guildId:{type:String,required:true,unique:true},data:{type:Object,required:true}}); EconomyModel=mongoose.model("Economy",econSchema); const userSchema=new mongoose.Schema({discordId:{type:String,unique:true,index:true},username:String,role:{type:String,default:"user"},createdAt:{type:Date,default:Date.now}}); UserModel=mongoose.model("User",userSchema); const serverSchema=new mongoose.Schema({guildId:{type:String,required:true,unique:true},name:String}); ServerModel=mongoose.model("Server",serverSchema); console.log("✅ Connected to MongoDB"); } catch(err){ console.error("Mongo connection error:",err.message); EconomyModel=null; UserModel=null; ServerModel=null; } }
const fs = require("fs").promises;
const JSON_PATH = path.join(__dirname,"economy.json");
async function ensureJSON(){ try{ await fs.access(JSON_PATH);}catch{ await fs.writeFile(JSON_PATH, JSON.stringify({},null,2)); } }
async function readAllJSON(){ await ensureJSON(); return JSON.parse(await fs.readFile(JSON_PATH,"utf8")); }
async function writeAllJSON(obj){ return fs.writeFile(JSON_PATH, JSON.stringify(obj,null,2)); }
async function getEconomy(guildId){ if (EconomyModel){ const doc=await EconomyModel.findOne({guildId}); return doc?doc.data:null; } else { const all=await readAllJSON(); return all[guildId]||null; } }
async function setEconomy(guildId,data){ if (EconomyModel){ const doc=await EconomyModel.findOneAndUpdate({guildId},{data},{upsert:true,new:true}); return doc.data; } else { const all=await readAllJSON(); all[guildId]=data; await writeAllJSON(all); return all[guildId]; } }
function verifyToken(req,res,next){ const auth=req.headers.authorization; if (!auth) return res.status(401).json({error:"Token not provided"}); const token=auth.split(" ")[1]; jwt.verify(token,SECRET_KEY,(err,user)=>{ if (err) return res.status(403).json({error:"Invalid token"}); req.user=user; next(); }); }
function allowJwtOrBot(req,res,next){ const apiKey=req.headers["x-api-key"]; if (apiKey && apiKey===BOT_API_KEY){ req.bot=true; return next(); } return verifyToken(req,res,next); }
app.get("/auth/discord",(req,res)=>{ const scope=encodeURIComponent("identify guilds"); const url=`https://discord.com/api/oauth2/authorize?client_id=${DISCORD_CLIENT_ID}&redirect_uri=${encodeURIComponent(DISCORD_REDIRECT_URI)}&response_type=code&scope=${scope}&prompt=consent`; res.redirect(url); });
app.get("/auth/discord/callback", async (req,res)=>{ const code=req.query.code; if (!code) return res.status(400).send("No code"); try{ const params=new URLSearchParams(); params.append("client_id",DISCORD_CLIENT_ID); params.append("client_secret",DISCORD_CLIENT_SECRET); params.append("grant_type","authorization_code"); params.append("code",code); params.append("redirect_uri",DISCORD_REDIRECT_URI); const tokenRes=await axios.post("https://discord.com/api/oauth2/token", params.toString(), { headers: { "Content-Type": "application/x-www-form-urlencoded" } }); const access_token=tokenRes.data.access_token; const userRes=await axios.get("https://discord.com/api/users/@me", { headers: { Authorization: `Bearer ${access_token}` } }); const guildsRes=await axios.get("https://discord.com/api/users/@me/guilds", { headers: { Authorization: `Bearer ${access_token}` } }); const guilds = guildsRes.data || []; const adminGuilds = guilds.filter(g => (BigInt(g.permissions) & 0x8n) === 0x8n); let allowedGuilds = adminGuilds; if (ServerModel){ const regs = await ServerModel.find({}, { guildId:1, _id:0 }); const regIds = regs.map(r=>r.guildId); allowedGuilds = adminGuilds.filter(g=> regIds.includes(g.id)); } if (UserModel){ await UserModel.findOneAndUpdate({ discordId: userRes.data.id }, { discordId: userRes.data.id, username: `${userRes.data.username}#${userRes.data.discriminator}` }, { upsert:true }); } const payload = { id: userRes.data.id, username: `${userRes.data.username}#${userRes.data.discriminator}`, guilds: allowedGuilds }; const token=jwt.sign(payload,SECRET_KEY,{expiresIn:"2h"}); const html=`<script>localStorage.setItem("token","${token}");localStorage.setItem("auth_user","${payload.username}");window.location.href="/index.html";</script><p>Redirecting...</p>`; res.send(html); }catch(err){ console.error(err.response?err.response.data:err.message); res.status(500).send("OAuth error"); } });
app.post("/api/register_guild", async (req,res)=>{ const apiKey=req.headers["x-api-key"]; if (!apiKey || apiKey!==BOT_API_KEY) return res.status(403).json({ error: "Invalid API key" }); const { guildId, name } = req.body; if (!guildId) return res.status(400).json({ error: "guildId required" }); if (ServerModel){ await ServerModel.findOneAndUpdate({ guildId }, { guildId, name }, { upsert:true }); } else { const all=await readAllJSON(); if (!all[guildId]) all[guildId]={coinRate:1.0,tax:5,baseIncome:100,__name:name||guildId}; await writeAllJSON(all); } res.json({ success:true }); });
app.post("/api/login", async (req,res)=>{ const { username,password } = req.body; const devs=[{username:"admin",password:"1234",role:"admin"}]; const user=devs.find(u=>u.username===username && u.password===password); if (!user) return res.status(401).json({ error:"Invalid credentials" }); const token=jwt.sign({ username:user.username, role:user.role }, SECRET_KEY, { expiresIn:"2h" }); res.json({ token, role:user.role }); });
app.get("/api/economy/:guildId", allowJwtOrBot, async (req,res)=>{ const guildId=req.params.guildId; const data=await getEconomy(guildId); if (!data) return res.status(404).json({ error:"Not found" }); res.json(data); });
app.post("/api/economy/:guildId", allowJwtOrBot, async (req,res)=>{ const guildId=req.params.guildId; const { values } = req.body; if (!req.bot && !req.user) return res.status(401).json({ error:"Unauthorized" }); if (req.user && req.user.guilds){ const allowed=req.user.guilds.find(g=>g.id===guildId); if (!allowed) return res.status(403).json({ error:"No permissions for this guild" }); } let current=await getEconomy(guildId)||{}; const updated={ ...current, ...values }; await setEconomy(guildId, updated); res.json({ success:true, updated }); });
app.get("/api/servers", allowJwtOrBot, async (req,res)=>{ if (ServerModel){ const docs=await ServerModel.find({}, { guildId:1, name:1, _id:0 }); return res.json(docs); } else { const all=await readAllJSON(); const entries=Object.keys(all).map(k=>({ guildId:k, name: all[k].__name || k })); return res.json(entries); } });
(async ()=>{ await initMongo(); await ensureJSON(); app.listen(port, ()=>console.log(`✅ VEET server listening on http://localhost:${port}`)); })();
